<section class="home1">
        <div class="logo">
            <h2>Restaurant</h2>
        </div>
        <div class="line">
        </div>
        <div class="navbar">
            <ul class="navbar-tekst">
                <li><a class="navbar-tekst" href="index.php">Home</a></li>
                <li><a class="navbar-tekst" href="menu.php">Menu</a></li>
                <li><a class="navbar-tekst" href="over-ons.php">over ons</a></li>
                <li><a class="navbar-tekst" href="#">reserveren</a></li>
                <li><a class="navbar-tekst" href="#">Contact</a></li>
                <li><a class="navbar-tekst" href="login.php">login</a></li>
            </ul>
        </div>
    </section>