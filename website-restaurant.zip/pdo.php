<?php

$host = "localhost/website-restaurant/";
$databasename = "menu";
$username = "root";
$passwword = "root";

$dsn = "mysql:host=$host;dbname=$databasename";

$databaseConnection = new PDO($dsn, $username, $password);