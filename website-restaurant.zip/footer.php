<section class="home4">
        <div class="restaurant-home-4-tekst"><h2>Bezoek ons hier</h2> </div>
        <div class="home4-line"></div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?
            pb=!1m18!1m12!1m3!1d6689.497045945778!2d46.12135
            567795463!3d-22.393450064591455!2m3!1f0!2f0!3f0!3
            m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x21de997c3c8128f
            9%3A0xff5212e6382f4cc9!2sBARKET!5e0!3m2!1snl!2snl!
            4v1678883427869!5m2!1snl!2snl" width="1300" height
            ="300" style="border:0;" allowfullscreen="" loadin
            g="lazy" referrerpolicy="no-referrer-when-downgrad
            e"></iframe>
        </div>
        <div class="home4-line-2"></div>
        <div class="information">
            <div class="information-1">
                <h2>Locatie</h2>
                <div class="information-1-1">'
                    <h2>Heyendaalseweg 98
                        5938 BG Nijmegen
                    </h2>

                </div>
            </div>
            <div class="information-2">
                <h2>Contact</h2>
                <div class="information-2-1">'
                    <h2>+31 640804319
                        info@naamrestaurant.nl
                    </h2>

                </div>
            </div>
            <div class="information-3">
                <h2>Openingstijden</h2>
                <div class="information-3-1">'
                    <h2>6 dagen per week geopend

                    </h2> 
                    <h2> </h2>
                    <h2>dinsdag t/m zondag vanaf 14:00

                    </h2>
                    <h2> </h2>
                    <h2>Keuken geopend van 17.00 tot 21.30 uur

                    </h2>
                    

                </div>
            </div>
            <div class="information-4">
                <h2>Volg ons</h2>
                <div class="information-4-1">'
                    <h2>Heyendaalseweg 98
                        5938 BG Nijmegen
                    </h2>

                </div>
            </div>
        </div>
    </section>